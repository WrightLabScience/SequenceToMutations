tests/test.sh clean tests
tests/test.sh test tests
